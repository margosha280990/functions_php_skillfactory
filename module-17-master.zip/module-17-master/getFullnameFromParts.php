<?php
    function getFullnameFromParts($surname, $name, $patronomyc){
        return $surname . ' ' . $name . ' ' . $patronomyc;
    }
?>
